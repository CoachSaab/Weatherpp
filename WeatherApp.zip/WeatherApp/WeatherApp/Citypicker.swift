//
//  Citypicker.swift
//  WeatherApp
//
//  Created by sagar on 04/06/23.
//

import UIKit
import MapKit

class Citypicker: UIViewController {
    
    let searchCompleter = MKLocalSearchCompleter()
    var searchResults = [MKLocalSearchCompletion]()
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var citySearchBar: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set the delegate for the search completer
        searchCompleter.delegate = self
        
        // Set up the table view
        tableView.dataSource = self
        tableView.delegate = self
        tableView.isHidden = true
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")

    }
    
}

// MARK: - UISearchBarDelegate

extension Citypicker: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchCompleter.queryFragment = searchText
        
        if searchText.isEmpty {
                 tableView.isHidden = true
                 searchBar.resignFirstResponder()
             } else {
                 searchCompleter.queryFragment = searchText
             }
         }
    }
    


// MARK: - MKLocalSearchCompleterDelegate

extension Citypicker: MKLocalSearchCompleterDelegate {
    
    func completerDidUpdateResults(_ completer: MKLocalSearchCompleter) {
        searchResults = completer.results
        tableView.reloadData()
        tableView.isHidden = false
    }
    
    func completer(_ completer: MKLocalSearchCompleter, didFailWithError error: Error) {
        print("Search completer failed with error: \(error.localizedDescription)")
    }
}

// MARK: - UITableViewDataSource, UITableViewDelegate

extension Citypicker: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchResults.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let searchResult = searchResults[indexPath.row]
        cell.textLabel?.text = searchResult.title
        cell.detailTextLabel?.text = searchResult.subtitle
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let searchResult = searchResults[indexPath.row]
        let searchRequest = MKLocalSearch.Request(completion: searchResult)
        /*let search = MKLocalSearch(request: searchRequest)
        search.start { response, error in
            if let placemark = response?.mapItems.first?.placemark {
                let city = placemark.locality ?? ""
                print("Selected City: \(city)")
            }
        }*/
        tableView.isHidden = true
        
        let search = MKLocalSearch(request: searchRequest)
        search.start { (response, error) in
            guard let coordinate = response?.mapItems[0].placemark.coordinate else {
                return
            }
            guard let name = response?.mapItems[0].name else {
            
                  return
            }
            var city = name
            print(city)
            
            UserDefaults.standard.set(name, forKey: "KeyOfCity")
            
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            
            let main = UIStoryboard(name: "Main", bundle: nil)
            let first = main.instantiateViewController(withIdentifier: "ViewController")
            self.present(first, animated: false,completion:nil)
            
        }
    }
}

