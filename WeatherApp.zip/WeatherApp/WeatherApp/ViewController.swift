//
//  ViewController.swift
//  WeatherApp
//
//  Created by sagar on 20/09/21.
//



import UIKit
import Alamofire
import Foundation
import AVFoundation

class ViewController: UIViewController {

        @IBOutlet weak var ShowCity: UILabel!
        @IBOutlet weak var ShowPresure: UILabel!
        @IBOutlet weak var MYimage: UIImageView!
        @IBOutlet weak var ShowWeathere: UILabel!
        @IBOutlet weak var ShowTemprature: UILabel!
        @IBOutlet weak var ShowHumidity: UILabel!
        @IBOutlet weak var ShowVisibility: UILabel!
    
    var defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let Fetch : String = defaults.object(forKey: "KeyOfCity")! as! String
        print(Fetch)
        
        let parameters : [String:Any] = [
            
            "q" : Fetch
            
        ]
        
        
        AF.request("https://api.openweathermap.org/data/2.5/weather?q=\(Fetch)&appid=c173859c05211b03110b83ca196f0a2a", parameters: parameters).responseJSON {
            response in
            print(response.result)
            
            switch response.result {
                
            case .success(let json ):
                
                
                DispatchQueue.main.async{
                    
                    let fetchDict : [String : Any] = json as! [String : Any]
                    
                    let Main = fetchDict["main"] as! NSDictionary
                    let Weather = fetchDict["weather"] as! NSArray
                    let weatherData = Weather[0] as! NSDictionary
                    let Visibility = fetchDict["visibility"] as! NSNumber
                    self.ShowVisibility.text = String(describing: Visibility)
                    
                  
                            
                    let Humidity = Main["humidity"] as! Int
                    self.ShowHumidity.text = String(Humidity)
                    
                    let Pressure = Main["pressure"] as! Int
                    self.ShowPresure.text = Pressure.description + "%"
                    
                    let Temprature = Main["temp"]!
                        if let kelvinTemp = Temprature as? Double {
                        let celsiusTemp = kelvinTemp - 273.15
                        self.ShowTemprature.text =  String(format: "%.0f", celsiusTemp) + "`c"
                        
                       
                      

                        
                    }
                    
                    let Name = fetchDict["name"]!
                    print("My city",Name)
                    self.ShowCity.text = Name as! String
                    
                    
                    let description = weatherData["description"] as! String
                    //print(description)
                    self.ShowWeathere.text = description
                    
                    //IMAGE LOAD
                    
                    if description == "scattered"{
                        self.MYimage.image = #imageLiteral(resourceName: "Scattered")
                    }
                    else if description == "overcast clouds"{
                        self.MYimage.image =  #imageLiteral(resourceName: "OverCast.png")                  }
                    else if description == "mist"{
                        self.MYimage.image = #imageLiteral(resourceName: "Mist.png")
                    }
                    else if description == "clear sky"{
                        self.MYimage.image = #imageLiteral(resourceName: "clear-sky")
                    }
                    else if description == "few clouds"{
                        self.MYimage.image = #imageLiteral(resourceName: "FewCloud.png")
                    }
                    else if description == "broken "{
                        self.MYimage.image = #imageLiteral(resourceName: "Broken.png")
                    }
                    
                    else if description == "haze"{
                        self.MYimage.image = #imageLiteral(resourceName: "haze.png")
                    }
                    else if description == "broken clouds"{
                        self.MYimage.image = #imageLiteral(resourceName: "Broken.png")

                        
                    }
                    else if description == "few clouds"{
                        
                    }
            
                    
                }
                
                
            case .failure(let error):
                print(error)
            }
            
        }
        
    }

}



